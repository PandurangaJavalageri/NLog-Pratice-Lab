﻿using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Task_4
{
    
    class Program
    {
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();

        static void Main(string[] args)
        {
            try
            {
                // Divide by zero exception
                int result = 10 / int.Parse("0");

                // Access an array out of bounds
                int[] array = { 1, 2, 3 };
                int value = array[5];

                // Null reference exception
                string text = null;
                int length = text.Length;

                // Custom exception
                throw new CustomException("This is a custom exception.");
            }
            catch (Exception ex)
            {
                // Log the exception details
                
                Logger.Error(ex, "Exception occurred");
            }
            finally
            {
                // Ensure any cleanup or finalization is done
                Console.WriteLine("Finally block executed");
            }

            // Keep the console open to review the output
            Console.ReadLine();
        }
    }

    // Custom exception class
    class CustomException : Exception
    {
        public CustomException(string message) : base(message) { }
    }

}
