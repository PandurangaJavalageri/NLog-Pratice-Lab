﻿using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NLog_Demo
{
    public class Program
    {
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();

        static void Main(string[] args)
        {
            try
            {
                MappedDiagnosticsContext.Set("CustomId", "123");
                MappedDiagnosticsContext.Set("SessionId", Guid.NewGuid().ToString());
                int n1 = 12;
                int n2 = 0;
                if(n2==0)
                {
                    throw new ApplicationException();
                }
                MappedDiagnosticsContext.Remove("CustomId");
                MappedDiagnosticsContext.Remove("SessionId");


            }
            catch (Exception ex)
            {
                Logger.Error(ex, "Goodbye cruel world pandu");
                Logger.Fatal(ex, "hello");
                Logger.Warn(ex,"undefined");
                Logger.Info(ex, "change divider");
                Logger.Error(ex, "Exception occurred: {Message} {@Context}", ex.Message, new { MethodName = "Main", ErrorCode = 500 });




                System.Console.ReadKey();
            }
        }
    }
}