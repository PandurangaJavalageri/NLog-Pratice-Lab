﻿using NLog.LayoutRenderers;
using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace task4._2
{

    public class program
    {
        private static readonly Logger Logger = LogManager.GetCurrentClassLogger();

        public static void Main(string[] args)
        {
            try
            {
                int n1 = 12;
                int n2 = 0;
                if (n2 == 0)
                {
                    throw new Exception();
                }
                int ans = n1 / n2;
            }
            catch (Exception ex)
            {
                Logger.Error(ex,"hello");
            }
        }



    }



        [LayoutRenderer("custom")]
        public class CustomLayoutRenderer : LayoutRenderer
        {
            protected override void Append(StringBuilder builder, LogEventInfo logEvent)
            {
                // Customize the log message format here based on your requirements
                builder.Append($"[{logEvent.TimeStamp:yyyy-MM-dd HH:mm:ss}] [{logEvent.Level.Name}] - {logEvent.Message}");
            }
        }
    

}
